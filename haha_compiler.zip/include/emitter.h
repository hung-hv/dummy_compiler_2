#ifndef EMITTER_H
#define EMITTER_H
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

uint8_t emit(FILE *fp, char* code);

#endif